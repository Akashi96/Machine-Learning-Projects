CS-534 Machine Learning
Implementation Assignment #2

Submitted by:	
				Akash Agarwal
				OSU ID NUMBER: 933-471-097
				Vishnupriya Nochikaduthekkedath Reghunathan
				OSU ID NUMBER: 933-620-571
				Anand P Koshy
				OSU ID NUMBER: 933-617-060

Instructions:

	Python Version: 
											Python 2.7.15

	Environment Setup and Libraries required:	
											numpy
											

	Command for execution:	
											python perceptron.py
