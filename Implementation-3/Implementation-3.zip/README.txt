CS-534 Machine Learning
Implementation Assignment #3
Decision Tree Ensemble for Optical Character Recognition


Submitted by:	
				Akash Agarwal
				OSU ID NUMBER: 933-471-097
				Vishnupriya Nochikaduthekkedath Reghunathan
				OSU ID NUMBER: 933-620-571
				Aashwin Vats
				OSU ID NUMBER: 933-615-112

Instructions:

	Python Version: 
											Python 2.7.15

	Environment Setup and Libraries required:	
											numpy
											All the dependencies, such as adaboost.py, decision_tree.py, preprocess.py, randomForest.py, treeFunc.py should remain in the same directory as main.py											

	Command for execution:	
											python main.py
